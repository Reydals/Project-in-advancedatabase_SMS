<?php
// Start session and database connection
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if user is admin - direct session check instead of function
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Initialize variables
$message = '';
$edit_user = null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_user'])) {
        $username = $conn->real_escape_string($_POST['username']);
        $password = $conn->real_escape_string($_POST['password']);
        $role = $conn->real_escape_string($_POST['role']);
        
        $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
        if ($conn->query($sql)) {
            $message = "User added successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
    
    if (isset($_POST['update_user'])) {
        $id = $conn->real_escape_string($_POST['user_id']);
        $username = $conn->real_escape_string($_POST['username']);
        $password = $conn->real_escape_string($_POST['password']);
        $role = $conn->real_escape_string($_POST['role']);
        
        $sql = "UPDATE users SET username='$username', role='$role'";
        if (!empty($password)) {
            $sql .= ", password='$password'";
        }
        $sql .= " WHERE user_id='$id'";
        
        if ($conn->query($sql)) {
            $message = "User updated successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}

// Handle delete - prevent deleting main admin user (user_id = 1)
if (isset($_GET['delete']) && !empty($_GET['delete']) && $_GET['delete'] != 1) {
    $id = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM users WHERE user_id='$id'");
    $message = "User deleted successfully!";
}

// Get user for editing
if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    $id = $conn->real_escape_string($_GET['edit']);
    $result = $conn->query("SELECT * FROM users WHERE user_id='$id'");
    if ($result && $result->num_rows > 0) {
        $edit_user = $result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Users - Sales System</title>
    <style>
        body { 
            font-family: Arial; 
            margin: 0; 
            background: #f5f5f5; 
        }
        .header { 
            background: #343a40; 
            color: white; 
            padding: 15px 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .sidebar { 
            background: #495057; 
            color: white; 
            width: 200px; 
            height: 100vh; 
            padding: 20px 0; 
            position: fixed; 
        }
        .sidebar a { 
            display: block; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
        }
        .sidebar a:hover { 
            background: #6c757d; 
        }
        .main-content { 
            margin-left: 200px; 
            padding: 20px; 
        }
        .btn { 
            background: #007bff; 
            color: white; 
            padding: 8px 15px; 
            border: none; 
            border-radius: 5px; 
            text-decoration: none; 
            display: inline-block; 
            cursor: pointer;
        }
        .btn-danger { 
            background: #dc3545; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            border-radius: 5px; 
            overflow: hidden; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        th { 
            background: #f8f9fa; 
        }
        tr:hover { 
            background: #f5f5f5; 
        }
        .message {
            background: #d4edda; 
            color: #155724; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .error {
            background: #f8d7da; 
            color: #721c24; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .role-admin {
            background: #dc3545;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: bold;
        }
        .role-cashier {
            background: #28a745;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Sales Management System</h1>
        <div>
            Welcome, <?php echo $_SESSION['username']; ?>! 
            (<?php echo $_SESSION['role']; ?>)
            <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
        </div>
    </div>

    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="categories.php">Categories</a>
        <a href="customers.php">Customers</a>
        <a href="sales.php">Sales</a>
        <a href="payments.php">Payments</a>
        <a href="suppliers.php">Suppliers</a>
        <a href="users.php" style="background: #007bff;">Users</a>
    </div>

    <div class="main-content">
        <h2>Manage Users</h2>
        
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Add/Edit Form -->
        <div class="form-container">
            <h3><?php echo $edit_user ? 'Edit User' : 'Add New User'; ?></h3>
            <form method="POST">
                <?php if ($edit_user): ?>
                    <input type="hidden" name="user_id" value="<?php echo $edit_user['user_id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Username:</label>
                        <input type="text" name="username" 
                               value="<?php echo $edit_user ? $edit_user['username'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label>Password:</label>
                        <input type="password" name="password" <?php echo $edit_user ? '' : 'required'; ?>>
                        <?php if ($edit_user): ?>
                            <small style="color: #666;">Leave blank to keep current password</small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Role:</label>
                        <select name="role" required>
                            <option value="cashier" <?php echo ($edit_user && $edit_user['role'] == 'cashier') ? 'selected' : ''; ?>>Cashier</option>
                            <option value="admin" <?php echo ($edit_user && $edit_user['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                        </select>
                    </div>
                </div>
                
                <div>
                    <?php if ($edit_user): ?>
                        <button type="submit" name="update_user" value="1" class="btn">Update User</button>
                        <a href="users.php" class="btn" style="background: #6c757d;">Cancel</a>
                    <?php else: ?>
                        <button type="submit" name="add_user" value="1" class="btn">Add User</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Users Table -->
        <div class="form-container">
            <h3>All Users</h3>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
                <?php
                $users = $conn->query("SELECT * FROM users ORDER BY user_id DESC");
                
                if ($users && $users->num_rows > 0) {
                    while($user = $users->fetch_assoc()) {
                        $role_class = $user['role'] == 'admin' ? 'role-admin' : 'role-cashier';
                        $role_display = ucfirst($user['role']);
                        
                        echo "<tr>
                            <td>{$user['user_id']}</td>
                            <td>{$user['username']}</td>
                            <td><span class='$role_class'>$role_display</span></td>
                            <td>";
                        
                        if ($user['user_id'] != 1) { // Don't show delete for main admin
                            echo "<a href='users.php?edit={$user['user_id']}' class='btn' style='background: #ffc107; color: black;'>Edit</a>
                                  <a href='users.php?delete={$user['user_id']}' class='btn btn-danger' 
                                     onclick='return confirm(\"Are you sure you want to delete this user?\")'>Delete</a>";
                        } else {
                            echo "<small>Main Admin</small>";
                        }
                        
                        echo "</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' style='text-align: center;'>No users found</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>