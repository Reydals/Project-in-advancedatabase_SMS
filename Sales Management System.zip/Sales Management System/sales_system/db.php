<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

// Simple authentication check
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Redirect if not logged in
if (!isset($login_page) && !isLoggedIn()) {
    header("Location: login.php");
    exit();
}
?>