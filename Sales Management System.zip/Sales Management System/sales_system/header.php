<?php
// This file is included in all pages except login
?>
<div class="header">
    <h1> Sales Management System</h1>
    <div>
        Welcome, <?php echo $_SESSION['username']; ?>! 
        (<?php echo $_SESSION['role']; ?>)
        <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
    </div>
</div>

<div class="sidebar">
    <a href="index.php" style="background: #007bff;"> Dashboard</a>
    <a href="products.php"> Products</a>
    <a href="categories.php"> Categories</a>
    <a href="customers.php"> Customers</a>
    <a href="sales.php"> Sales</a>
    <a href="payments.php"> Payments</a>
    <a href="suppliers.php"> Suppliers</a>
    <a href="users.php"> Users</a>
</div>