CREATE DATABASE IF NOT EXISTS sales_system;
USE sales_system;

