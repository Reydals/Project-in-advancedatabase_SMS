<?php
// Start session and database connection
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Sales System</title>
    <style>
        body { 
            font-family: Arial; 
            margin: 0; 
            background: #f5f5f5; 
        }
        .header { 
            background: #343a40; 
            color: white; 
            padding: 15px 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .sidebar { 
            background: #495057; 
            color: white; 
            width: 200px; 
            height: 100vh; 
            padding: 20px 0; 
            position: fixed; 
        }
        .sidebar a { 
            display: block; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
        }
        .sidebar a:hover { 
            background: #6c757d; 
        }
        .main-content { 
            margin-left: 200px; 
            padding: 20px; 
        }
        .cards { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 20px; 
            margin-bottom: 30px; 
        }
        .card { 
            background: white; 
            padding: 20px; 
            border-radius: 5px; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
            text-align: center; 
        }
        .card h3 { 
            margin: 0; 
            font-size: 2em; 
            color: #007bff; 
        }
        .btn { 
            background: #007bff; 
            color: white; 
            padding: 8px 15px; 
            border: none; 
            border-radius: 5px; 
            text-decoration: none; 
            display: inline-block; 
        }
        .btn-danger { 
            background: #dc3545; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            border-radius: 5px; 
            overflow: hidden; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        th { 
            background: #f8f9fa; 
        }
        tr:hover { 
            background: #f5f5f5; 
        }
    </style>
</head>
<body>
    <div class="header">
        <h1> Sales Management System</h1>
        <div>
            Welcome, <?php echo $_SESSION['username']; ?>! 
            (<?php echo $_SESSION['role']; ?>)
            <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
        </div>
    </div>

    <div class="sidebar">
        <a href="index.php" style="background: #007bff;"> Dashboard</a>
        <a href="products.php"> Products</a>
        <a href="categories.php"> Categories</a>
        <a href="customers.php"> Customers</a>
        <a href="sales.php"> Sales</a>
        <a href="payments.php"> Payments</a>
        <a href="suppliers.php"> Suppliers</a>
        <a href="users.php"> Users</a>
    </div>

    <div class="main-content">
        <h2>Dashboard Overview</h2>
        
        <div class="cards">
            <?php
            // Get counts for dashboard cards
            $tables = [
                'Products' => 'products',
                'Categories' => 'categories', 
                'Customers' => 'customers',
                'Sales' => 'sales',
                'Suppliers' => 'suppliers',
                'Payments' => 'payments'
            ];
            
            foreach ($tables as $name => $table) {
                $result = $conn->query("SELECT COUNT(*) as count FROM $table");
                $count = $result->fetch_assoc()['count'];
                echo "
                <div class='card'>
                    <h3>$count</h3>
                    <p>$name</p>
                </div>";
            }
            ?>
        </div>

        <h3>Recent Sales</h3>
        <table>
            <tr>
                <th>Sale ID</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Amount</th>
            </tr>
            <?php
            $sales = $conn->query("
                SELECT s.sale_id, c.name, s.sale_date, s.total_amount 
                FROM sales s 
                LEFT JOIN customers c ON s.customer_id = c.customer_id 
                ORDER BY s.sale_date DESC 
                LIMIT 5
            ");
            
            if ($sales->num_rows > 0) {
                while($sale = $sales->fetch_assoc()) {
                    echo "<tr>
                        <td>#{$sale['sale_id']}</td>
                        <td>{$sale['name']}</td>
                        <td>" . date('M j, Y', strtotime($sale['sale_date'])) . "</td>
                        <td>₱" . number_format($sale['total_amount'], 2) . "</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No sales found</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>