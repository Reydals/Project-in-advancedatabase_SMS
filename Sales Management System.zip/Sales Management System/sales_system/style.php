<?php
// This acts as a CSS file but with .php extension
header('Content-Type: text/css');
?>
<style>
body { 
    font-family: Arial; 
    margin: 0; 
    background: #f5f5f5; 
}
.header { 
    background: #343a40; 
    color: white; 
    padding: 15px 20px; 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
}
.sidebar { 
    background: #495057; 
    color: white; 
    width: 200px; 
    height: 100vh; 
    padding: 20px 0; 
    position: fixed; 
}
.sidebar a { 
    display: block; 
    color: white; 
    padding: 10px 20px; 
    text-decoration: none; 
}
.sidebar a:hover { 
    background: #6c757d; 
}
.main-content { 
    margin-left: 200px; 
    padding: 20px; 
}
.cards { 
    display: grid; 
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
    gap: 20px; 
    margin-bottom: 30px; 
}
.card { 
    background: white; 
    padding: 20px; 
    border-radius: 5px; 
    box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
    text-align: center; 
}
.card h3 { 
    margin: 0; 
    font-size: 2em; 
    color: #007bff; 
}
.btn { 
    background: #007bff; 
    color: white; 
    padding: 8px 15px; 
    border: none; 
    border-radius: 5px; 
    text-decoration: none; 
    display: inline-block; 
    cursor: pointer;
}
.btn-danger { 
    background: #dc3545; 
}
table { 
    width: 100%; 
    border-collapse: collapse; 
    background: white; 
    border-radius: 5px; 
    overflow: hidden; 
    box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
}
th, td { 
    padding: 12px 15px; 
    text-align: left; 
    border-bottom: 1px solid #ddd; 
}
th { 
    background: #f8f9fa; 
}
tr:hover { 
    background: #f5f5f5; 
}
</style>