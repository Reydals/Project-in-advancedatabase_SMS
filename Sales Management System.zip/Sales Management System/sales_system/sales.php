<?php
// Start session and database connection
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$message = '';

// Handle form submissions - ONLY if form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_sale'])) {
        $customer_id = $conn->real_escape_string($_POST['customer_id']);
        $user_id = $_SESSION['user_id'];
        
        $conn->query("INSERT INTO sales (customer_id, user_id, total_amount) VALUES ('$customer_id', '$user_id', 0)");
        $sale_id = $conn->insert_id;
        header("Location: sale_details.php?id=$sale_id");
        exit();
    }
}

// Handle delete - ONLY if delete parameter exists
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $id = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM sales WHERE sale_id='$id'");
    $message = "Sale deleted successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sales - Sales System</title>
    <style>
        body { 
            font-family: Arial; 
            margin: 0; 
            background: #f5f5f5; 
        }
        .header { 
            background: #343a40; 
            color: white; 
            padding: 15px 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .sidebar { 
            background: #495057; 
            color: white; 
            width: 200px; 
            height: 100vh; 
            padding: 20px 0; 
            position: fixed; 
        }
        .sidebar a { 
            display: block; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
        }
        .sidebar a:hover { 
            background: #6c757d; 
        }
        .main-content { 
            margin-left: 200px; 
            padding: 20px; 
        }
        .btn { 
            background: #007bff; 
            color: white; 
            padding: 8px 15px; 
            border: none; 
            border-radius: 5px; 
            text-decoration: none; 
            display: inline-block; 
            cursor: pointer;
        }
        .btn-danger { 
            background: #dc3545; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            border-radius: 5px; 
            overflow: hidden; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        th { 
            background: #f8f9fa; 
        }
        tr:hover { 
            background: #f5f5f5; 
        }
        .message {
            background: #d4edda; 
            color: #155724; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select {
            width: 100%;
            max-width: 400px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1> Sales Management System</h1>
        <div>
            Welcome, <?php echo $_SESSION['username']; ?>! 
            (<?php echo $_SESSION['role']; ?>)
            <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
        </div>
    </div>

    <div class="sidebar">
        <a href="index.php"> Dashboard</a>
        <a href="products.php"> Products</a>
        <a href="categories.php"> Categories</a>
        <a href="customers.php"> Customers</a>
        <a href="sales.php" style="background: #007bff;"> Sales</a>
        <a href="payments.php"> Payments</a>
        <a href="suppliers.php"> Suppliers</a>
        <a href="users.php"> Users</a>
    </div>

    <div class="main-content">
        <h2> Manage Sales</h2>
        
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- New Sale Form -->
        <div class="form-container">
            <h3>Create New Sale</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Select Customer:</label>
                    <select name="customer_id" required>
                        <option value="">Select Customer</option>
                        <?php
                        $customers = $conn->query("SELECT * FROM customers");
                        if ($customers && $customers->num_rows > 0) {
                            while($customer = $customers->fetch_assoc()) {
                                echo "<option value='{$customer['customer_id']}'>{$customer['name']} - {$customer['contact']}</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
                <button type="submit" name="create_sale" value="1" class="btn">Create New Sale</button>
            </form>
        </div>

        <!-- Sales Table -->
        <div class="form-container">
            <h3>All Sales</h3>
            <table>
                <tr>
                    <th>Sale ID</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Total Amount</th>
                    <th>Actions</th>
                </tr>
                <?php
                $sales = $conn->query("
                    SELECT s.*, c.name as customer_name 
                    FROM sales s 
                    LEFT JOIN customers c ON s.customer_id = c.customer_id 
                    ORDER BY s.sale_date DESC
                ");
                
                if ($sales && $sales->num_rows > 0) {
                    while($sale = $sales->fetch_assoc()) {
                        echo "<tr>
                            <td>#{$sale['sale_id']}</td>
                            <td>{$sale['customer_name']}</td>
                            <td>" . date('M j, Y H:i', strtotime($sale['sale_date'])) . "</td>
                            <td>₱" . number_format($sale['total_amount'], 2) . "</td>
                            <td>
                                <a href='sale_details.php?id={$sale['sale_id']}' class='btn'>View Details</a>
                                <a href='sales.php?delete={$sale['sale_id']}' class='btn btn-danger' 
                                   onclick='return confirm(\"Are you sure you want to delete this sale?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' style='text-align: center;'>No sales found</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>