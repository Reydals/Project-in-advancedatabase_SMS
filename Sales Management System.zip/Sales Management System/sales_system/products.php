<?php
// Start session and database connection
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$message = '';
$error = '';
$edit_product = null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_product'])) {
        $name = $conn->real_escape_string($_POST['product_name']);
        $category = $conn->real_escape_string($_POST['category_id']);
        $price = $conn->real_escape_string($_POST['price']);
        $stock = $conn->real_escape_string($_POST['stock']);
        
        $sql = "INSERT INTO products (product_name, category_id, price, stock) 
                VALUES ('$name', '$category', '$price', '$stock')";
        
        if ($conn->query($sql)) {
            $message = "Product added successfully!";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
    
    if (isset($_POST['update_product'])) {
        $id = $conn->real_escape_string($_POST['product_id']);
        $name = $conn->real_escape_string($_POST['product_name']);
        $category = $conn->real_escape_string($_POST['category_id']);
        $price = $conn->real_escape_string($_POST['price']);
        $stock = $conn->real_escape_string($_POST['stock']);
        
        $sql = "UPDATE products SET 
                product_name='$name', 
                category_id='$category', 
                price='$price', 
                stock='$stock' 
                WHERE product_id='$id'";
        
        if ($conn->query($sql)) {
            $message = "Product updated successfully!";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM products WHERE product_id='$id'");
    $message = "Product deleted successfully!";
}

// Get categories for dropdown
$categories = $conn->query("SELECT * FROM categories");

// Get product for editing
if (isset($_GET['edit'])) {
    $id = $conn->real_escape_string($_GET['edit']);
    $result = $conn->query("SELECT * FROM products WHERE product_id='$id'");
    $edit_product = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products - Sales System</title>
    <style>
        body { 
            font-family: Arial; 
            margin: 0; 
            background: #f5f5f5; 
        }
        .header { 
            background: #343a40; 
            color: white; 
            padding: 15px 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .sidebar { 
            background: #495057; 
            color: white; 
            width: 200px; 
            height: 100vh; 
            padding: 20px 0; 
            position: fixed; 
        }
        .sidebar a { 
            display: block; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
        }
        .sidebar a:hover { 
            background: #6c757d; 
        }
        .main-content { 
            margin-left: 200px; 
            padding: 20px; 
        }
        .btn { 
            background: #007bff; 
            color: white; 
            padding: 8px 15px; 
            border: none; 
            border-radius: 5px; 
            text-decoration: none; 
            display: inline-block; 
            cursor: pointer;
        }
        .btn-danger { 
            background: #dc3545; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            border-radius: 5px; 
            overflow: hidden; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        th { 
            background: #f8f9fa; 
        }
        tr:hover { 
            background: #f5f5f5; 
        }
        .message {
            background: #d4edda; 
            color: #155724; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .error {
            background: #f8d7da; 
            color: #721c24; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1> Sales Management System</h1>
        <div>
            Welcome, <?php echo $_SESSION['username']; ?>! 
            (<?php echo $_SESSION['role']; ?>)
            <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
        </div>
    </div>

    <div class="sidebar">
        <a href="index.php"> Dashboard</a>
        <a href="products.php" style="background: #007bff;"> Products</a>
        <a href="categories.php"> Categories</a>
        <a href="customers.php"> Customers</a>
        <a href="sales.php"> Sales</a>
        <a href="payments.php"> Payments</a>
        <a href="suppliers.php"> Suppliers</a>
        <a href="users.php"> Users</a>
    </div>

    <div class="main-content">
        <h2> Manage Products</h2>
        
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Add/Edit Form -->
        <div class="form-container">
            <h3><?php echo $edit_product ? 'Edit Product' : 'Add New Product'; ?></h3>
            <form method="POST">
                <?php if ($edit_product): ?>
                    <input type="hidden" name="product_id" value="<?php echo $edit_product['product_id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Product Name:</label>
                        <input type="text" name="product_name" 
                               value="<?php echo $edit_product ? $edit_product['product_name'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label>Category:</label>
                        <select name="category_id" required>
                            <option value="">Select Category</option>
                            <?php 
                            if ($categories && $categories->num_rows > 0) {
                                // Reset pointer to beginning
                                $categories->data_seek(0);
                                while($cat = $categories->fetch_assoc()): 
                            ?>
                                <option value="<?php echo $cat['category_id']; ?>" 
                                    <?php echo ($edit_product && $edit_product['category_id'] == $cat['category_id']) ? 'selected' : ''; ?>>
                                    <?php echo $cat['category_name']; ?>
                                </option>
                            <?php 
                                endwhile;
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Price (₱):</label>
                        <input type="number" step="0.01" name="price" 
                               value="<?php echo $edit_product ? $edit_product['price'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label>Stock:</label>
                        <input type="number" name="stock" 
                               value="<?php echo $edit_product ? $edit_product['stock'] : ''; ?>" 
                               required>
                    </div>
                </div>
                
                <div style="margin-top: 20px;">
                    <?php if ($edit_product): ?>
                        <button type="submit" name="update_product" value="1" class="btn">Update Product</button>
                        <a href="products.php" class="btn" style="background: #6c757d;">Cancel</a>
                    <?php else: ?>
                        <button type="submit" name="add_product" value="1" class="btn">Add Product</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Products Table -->
        <div class="form-container">
            <h3>All Products</h3>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
                <?php
                $products = $conn->query("
                    SELECT p.*, c.category_name 
                    FROM products p 
                    LEFT JOIN categories c ON p.category_id = c.category_id 
                    ORDER BY p.product_id DESC
                ");
                
                if ($products && $products->num_rows > 0) {
                    while($product = $products->fetch_assoc()) {
                        $stock_color = $product['stock'] < 10 ? 'color: red; font-weight: bold;' : '';
                        echo "<tr>
                            <td>{$product['product_id']}</td>
                            <td>{$product['product_name']}</td>
                            <td>{$product['category_name']}</td>
                            <td>₱" . number_format($product['price'], 2) . "</td>
                            <td style='$stock_color'>{$product['stock']}</td>
                            <td>
                                <a href='products.php?edit={$product['product_id']}' class='btn' style='background: #ffc107; color: black;'>Edit</a>
                                <a href='products.php?delete={$product['product_id']}' class='btn btn-danger' 
                                   onclick='return confirm(\"Are you sure you want to delete this product?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' style='text-align: center;'>No products found</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>