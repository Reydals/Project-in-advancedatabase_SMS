<?php
// Start session and database connection
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$message = '';
$edit_supplier = null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_supplier'])) {
        $name = $conn->real_escape_string($_POST['supplier_name']);
        $contact = $conn->real_escape_string($_POST['contact']);
        
        $sql = "INSERT INTO suppliers (supplier_name, contact) VALUES ('$name', '$contact')";
        if ($conn->query($sql)) {
            $message = "Supplier added successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
    
    if (isset($_POST['update_supplier'])) {
        $id = $conn->real_escape_string($_POST['supplier_id']);
        $name = $conn->real_escape_string($_POST['supplier_name']);
        $contact = $conn->real_escape_string($_POST['contact']);
        
        $sql = "UPDATE suppliers SET supplier_name='$name', contact='$contact' WHERE supplier_id='$id'";
        if ($conn->query($sql)) {
            $message = "Supplier updated successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}

// Handle delete
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $id = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM suppliers WHERE supplier_id='$id'");
    $message = "Supplier deleted successfully!";
}

// Get supplier for editing
if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    $id = $conn->real_escape_string($_GET['edit']);
    $result = $conn->query("SELECT * FROM suppliers WHERE supplier_id='$id'");
    if ($result && $result->num_rows > 0) {
        $edit_supplier = $result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Suppliers - Sales System</title>
    <style>
        body { 
            font-family: Arial; 
            margin: 0; 
            background: #f5f5f5; 
        }
        .header { 
            background: #343a40; 
            color: white; 
            padding: 15px 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .sidebar { 
            background: #495057; 
            color: white; 
            width: 200px; 
            height: 100vh; 
            padding: 20px 0; 
            position: fixed; 
        }
        .sidebar a { 
            display: block; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
        }
        .sidebar a:hover { 
            background: #6c757d; 
        }
        .main-content { 
            margin-left: 200px; 
            padding: 20px; 
        }
        .btn { 
            background: #007bff; 
            color: white; 
            padding: 8px 15px; 
            border: none; 
            border-radius: 5px; 
            text-decoration: none; 
            display: inline-block; 
            cursor: pointer;
        }
        .btn-danger { 
            background: #dc3545; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            border-radius: 5px; 
            overflow: hidden; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        th { 
            background: #f8f9fa; 
        }
        tr:hover { 
            background: #f5f5f5; 
        }
        .message {
            background: #d4edda; 
            color: #155724; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .error {
            background: #f8d7da; 
            color: #721c24; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Sales Management System</h1>
        <div>
            Welcome, <?php echo $_SESSION['username']; ?>! 
            (<?php echo $_SESSION['role']; ?>)
            <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
        </div>
    </div>

    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="categories.php">Categories</a>
        <a href="customers.php">Customers</a>
        <a href="sales.php">Sales</a>
        <a href="payments.php">Payments</a>
        <a href="suppliers.php" style="background: #007bff;">Suppliers</a>
        <a href="users.php">Users</a>
    </div>

    <div class="main-content">
        <h2>Manage Suppliers</h2>
        
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Add/Edit Form -->
        <div class="form-container">
            <h3><?php echo $edit_supplier ? 'Edit Supplier' : 'Add New Supplier'; ?></h3>
            <form method="POST">
                <?php if ($edit_supplier): ?>
                    <input type="hidden" name="supplier_id" value="<?php echo $edit_supplier['supplier_id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Supplier Name:</label>
                        <input type="text" name="supplier_name" 
                               value="<?php echo $edit_supplier ? $edit_supplier['supplier_name'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label>Contact:</label>
                        <input type="text" name="contact" 
                               value="<?php echo $edit_supplier ? $edit_supplier['contact'] : ''; ?>" 
                               required>
                    </div>
                </div>
                
                <div>
                    <?php if ($edit_supplier): ?>
                        <button type="submit" name="update_supplier" value="1" class="btn">Update Supplier</button>
                        <a href="suppliers.php" class="btn" style="background: #6c757d;">Cancel</a>
                    <?php else: ?>
                        <button type="submit" name="add_supplier" value="1" class="btn">Add Supplier</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Suppliers Table -->
        <div class="form-container">
            <h3>All Suppliers</h3>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Supplier Name</th>
                    <th>Contact</th>
                    <th>Actions</th>
                </tr>
                <?php
                $suppliers = $conn->query("SELECT * FROM suppliers ORDER BY supplier_id DESC");
                
                if ($suppliers && $suppliers->num_rows > 0) {
                    while($supplier = $suppliers->fetch_assoc()) {
                        echo "<tr>
                            <td>{$supplier['supplier_id']}</td>
                            <td>{$supplier['supplier_name']}</td>
                            <td>{$supplier['contact']}</td>
                            <td>
                                <a href='suppliers.php?edit={$supplier['supplier_id']}' class='btn' style='background: #ffc107; color: black;'>Edit</a>
                                <a href='suppliers.php?delete={$supplier['supplier_id']}' class='btn btn-danger' 
                                   onclick='return confirm(\"Are you sure you want to delete this supplier?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' style='text-align: center;'>No suppliers found</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>