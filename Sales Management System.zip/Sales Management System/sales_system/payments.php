<?php
// Start session and database connection
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_payment'])) {
        $sale_id = $conn->real_escape_string($_POST['sale_id']);
        $amount_paid = $conn->real_escape_string($_POST['amount_paid']);
        $payment_method = $conn->real_escape_string($_POST['payment_method']);
        
        // Insert payment
        $sql = "INSERT INTO payments (sale_id, amount_paid, payment_method) 
                VALUES ('$sale_id', '$amount_paid', '$payment_method')";
        
        if ($conn->query($sql)) {
            // Update sale total amount if needed
            $update_sql = "UPDATE sales SET total_amount = total_amount + $amount_paid WHERE sale_id = '$sale_id'";
            $conn->query($update_sql);
            
            $message = "Payment added successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}

// Handle delete
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $payment_id = $conn->real_escape_string($_GET['delete']);
    
    // Get payment details before deleting
    $payment_result = $conn->query("SELECT * FROM payments WHERE payment_id = '$payment_id'");
    if ($payment_result && $payment_result->num_rows > 0) {
        $payment = $payment_result->fetch_assoc();
        
        // Delete the payment
        $conn->query("DELETE FROM payments WHERE payment_id = '$payment_id'");
        
        // Update sale total amount
        $update_sql = "UPDATE sales SET total_amount = total_amount - {$payment['amount_paid']} WHERE sale_id = '{$payment['sale_id']}'";
        $conn->query($update_sql);
        
        $message = "Payment deleted successfully!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payments - Sales System</title>
    <style>
        body { 
            font-family: Arial; 
            margin: 0; 
            background: #f5f5f5; 
        }
        .header { 
            background: #343a40; 
            color: white; 
            padding: 15px 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .sidebar { 
            background: #495057; 
            color: white; 
            width: 200px; 
            height: 100vh; 
            padding: 20px 0; 
            position: fixed; 
        }
        .sidebar a { 
            display: block; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
        }
        .sidebar a:hover { 
            background: #6c757d; 
        }
        .main-content { 
            margin-left: 200px; 
            padding: 20px; 
        }
        .btn { 
            background: #007bff; 
            color: white; 
            padding: 8px 15px; 
            border: none; 
            border-radius: 5px; 
            text-decoration: none; 
            display: inline-block; 
            cursor: pointer;
        }
        .btn-danger { 
            background: #dc3545; 
        }
        .btn-success { 
            background: #28a745; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            border-radius: 5px; 
            overflow: hidden; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        th { 
            background: #f8f9fa; 
        }
        tr:hover { 
            background: #f5f5f5; 
        }
        .message {
            background: #d4edda; 
            color: #155724; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .error {
            background: #f8d7da; 
            color: #721c24; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .amount-paid {
            color: #28a745;
            font-weight: bold;
        }
        .payment-method {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: bold;
        }
        .cash { background: #d4edda; color: #155724; }
        .card { background: #cce7ff; color: #004085; }
        .transfer { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Sales Management System</h1>
        <div>
            Welcome, <?php echo $_SESSION['username']; ?>! 
            (<?php echo $_SESSION['role']; ?>)
            <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
        </div>
    </div>

    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="categories.php">Categories</a>
        <a href="customers.php">Customers</a>
        <a href="sales.php">Sales</a>
        <a href="payments.php" style="background: #007bff;">Payments</a>
        <a href="suppliers.php">Suppliers</a>
        <a href="users.php">Users</a>
    </div>

    <div class="main-content">
        <h2>Manage Payments</h2>
        
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Add Payment Form -->
        <div class="form-container">
            <h3>Add New Payment</h3>
            <form method="POST">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Sale:</label>
                        <select name="sale_id" required>
                            <option value="">Select Sale</option>
                            <?php
                            $sales = $conn->query("
                                SELECT s.sale_id, s.total_amount, c.name as customer_name 
                                FROM sales s 
                                LEFT JOIN customers c ON s.customer_id = c.customer_id 
                                ORDER BY s.sale_id DESC
                            ");
                            if ($sales && $sales->num_rows > 0) {
                                while($sale = $sales->fetch_assoc()) {
                                    echo "<option value='{$sale['sale_id']}'>
                                        Sale #{$sale['sale_id']} - {$sale['customer_name']} (₱" . number_format($sale['total_amount'], 2) . ")
                                    </option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Method:</label>
                        <select name="payment_method" required>
                            <option value="cash">Cash</option>
                            <option value="card">Card</option>
                            <option value="transfer">Bank Transfer</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Amount Paid (₱):</label>
                        <input type="number" step="0.01" name="amount_paid" required>
                    </div>
                </div>
                
                <button type="submit" name="add_payment" value="1" class="btn btn-success">Add Payment</button>
            </form>
        </div>

        <!-- Payments Table -->
        <div class="form-container">
            <h3>All Payments</h3>
            <table>
                <tr>
                    <th>Payment ID</th>
                    <th>Sale ID</th>
                    <th>Customer</th>
                    <th>Amount Paid</th>
                    <th>Payment Method</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
                <?php
                $payments = $conn->query("
                    SELECT p.*, s.total_amount, c.name as customer_name 
                    FROM payments p 
                    LEFT JOIN sales s ON p.sale_id = s.sale_id 
                    LEFT JOIN customers c ON s.customer_id = c.customer_id 
                    ORDER BY p.payment_date DESC
                ");
                
                if ($payments && $payments->num_rows > 0) {
                    while($payment = $payments->fetch_assoc()) {
                        $method_class = $payment['payment_method'] ?? 'cash';
                        $method_display = ucfirst($method_class);
                        
                        echo "<tr>
                            <td>#{$payment['payment_id']}</td>
                            <td>#{$payment['sale_id']}</td>
                            <td>{$payment['customer_name']}</td>
                            <td class='amount-paid'>₱" . number_format($payment['amount_paid'], 2) . "</td>
                            <td>
                                <span class='payment-method $method_class'>$method_display</span>
                            </td>
                            <td>" . date('M j, Y H:i', strtotime($payment['payment_date'])) . "</td>
                            <td>
                                <a href='payments.php?delete={$payment['payment_id']}' class='btn btn-danger' 
                                   onclick='return confirm(\"Are you sure you want to delete this payment?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' style='text-align: center;'>No payments found</td></tr>";
                }
                ?>
            </table>
        </div>

        <!-- Payment Statistics -->
        <div class="form-container">
            <h3>Payment Statistics</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <?php
                // Total payments
                $total_result = $conn->query("SELECT COALESCE(SUM(amount_paid), 0) as total FROM payments");
                $total_payments = $total_result->fetch_assoc()['total'];
                
                // Payment methods count
                $cash_result = $conn->query("SELECT COUNT(*) as count FROM payments WHERE payment_method = 'cash'");
                $cash_count = $cash_result->fetch_assoc()['count'];
                
                $card_result = $conn->query("SELECT COUNT(*) as count FROM payments WHERE payment_method = 'card'");
                $card_count = $card_result->fetch_assoc()['count'];
                
                $transfer_result = $conn->query("SELECT COUNT(*) as count FROM payments WHERE payment_method = 'transfer'");
                $transfer_count = $transfer_result->fetch_assoc()['count'];
                ?>
                
                <div style="background: white; padding: 20px; border-radius: 5px; text-align: center; border-left: 4px solid #007bff;">
                    <h3 style="margin: 0; color: #007bff;">₱<?php echo number_format($total_payments, 2); ?></h3>
                    <p style="margin: 5px 0 0 0; color: #666;">Total Payments</p>
                </div>
                
                <div style="background: white; padding: 20px; border-radius: 5px; text-align: center; border-left: 4px solid #28a745;">
                    <h3 style="margin: 0; color: #28a745;"><?php echo $cash_count; ?></h3>
                    <p style="margin: 5px 0 0 0; color: #666;">Cash Payments</p>
                </div>
                
                <div style="background: white; padding: 20px; border-radius: 5px; text-align: center; border-left: 4px solid #17a2b8;">
                    <h3 style="margin: 0; color: #17a2b8;"><?php echo $card_count; ?></h3>
                    <p style="margin: 5px 0 0 0; color: #666;">Card Payments</p>
                </div>
                
                <div style="background: white; padding: 20px; border-radius: 5px; text-align: center; border-left: 4px solid #ffc107;">
                    <h3 style="margin: 0; color: #ffc107;"><?php echo $transfer_count; ?></h3>
                    <p style="margin: 5px 0 0 0; color: #666;">Transfer Payments</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>