<?php
// Start session and database connection
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sales_system";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$message = '';
$error = '';
$edit_customer = null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_customer'])) {
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $contact = $conn->real_escape_string($_POST['contact']);
        $address = $conn->real_escape_string($_POST['address']);
        
        $sql = "INSERT INTO customers (name, email, contact, address) 
                VALUES ('$name', '$email', '$contact', '$address')";
        
        if ($conn->query($sql)) {
            $message = "Customer added successfully!";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
    
    if (isset($_POST['update_customer'])) {
        $customer_id = $conn->real_escape_string($_POST['customer_id']);
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $contact = $conn->real_escape_string($_POST['contact']);
        $address = $conn->real_escape_string($_POST['address']);
        
        $sql = "UPDATE customers SET 
                name = '$name',
                email = '$email',
                contact = '$contact',
                address = '$address'
                WHERE customer_id = '$customer_id'";
        
        if ($conn->query($sql)) {
            $message = "Customer updated successfully!";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

// Handle delete
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $customer_id = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM customers WHERE customer_id = '$customer_id'");
    $message = "Customer deleted successfully!";
}

// Get customer data for editing
if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    $customer_id = $conn->real_escape_string($_GET['edit']);
    $result = $conn->query("SELECT * FROM customers WHERE customer_id = '$customer_id'");
    if ($result && $result->num_rows > 0) {
        $edit_customer = $result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customers - Sales System</title>
    <style>
        body { 
            font-family: Arial; 
            margin: 0; 
            background: #f5f5f5; 
        }
        .header { 
            background: #343a40; 
            color: white; 
            padding: 15px 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .sidebar { 
            background: #495057; 
            color: white; 
            width: 200px; 
            height: 100vh; 
            padding: 20px 0; 
            position: fixed; 
        }
        .sidebar a { 
            display: block; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
        }
        .sidebar a:hover { 
            background: #6c757d; 
        }
        .main-content { 
            margin-left: 200px; 
            padding: 20px; 
        }
        .btn { 
            background: #007bff; 
            color: white; 
            padding: 8px 15px; 
            border: none; 
            border-radius: 5px; 
            text-decoration: none; 
            display: inline-block; 
            cursor: pointer;
        }
        .btn-danger { 
            background: #dc3545; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            border-radius: 5px; 
            overflow: hidden; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        th { 
            background: #f8f9fa; 
        }
        tr:hover { 
            background: #f5f5f5; 
        }
        .message {
            background: #d4edda; 
            color: #155724; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .error {
            background: #f8d7da; 
            color: #721c24; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 15px;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1> Sales Management System</h1>
        <div>
            Welcome, <?php echo $_SESSION['username']; ?>! 
            (<?php echo $_SESSION['role']; ?>)
            <a href="logout.php" style="color: white; margin-left: 15px;">Logout</a>
        </div>
    </div>

    <div class="sidebar">
        <a href="index.php"> Dashboard</a>
        <a href="products.php"> Products</a>
        <a href="categories.php"> Categories</a>
        <a href="customers.php" style="background: #007bff;"> Customers</a>
        <a href="sales.php"> Sales</a>
        <a href="payments.php"> Payments</a>
        <a href="suppliers.php"> Suppliers</a>
        <a href="users.php"> Users</a>
    </div>

    <div class="main-content">
        <h2> Manage Customers</h2>
        
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Add/Edit Customer Form -->
        <div class="form-container">
            <h3><?php echo $edit_customer ? 'Edit Customer' : 'Add New Customer'; ?></h3>
            <form method="POST">
                <?php if ($edit_customer): ?>
                    <input type="hidden" name="customer_id" value="<?php echo $edit_customer['customer_id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Full Name:</label>
                        <input type="text" name="name" 
                               value="<?php echo $edit_customer ? $edit_customer['name'] : ''; ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" name="email" 
                               value="<?php echo $edit_customer ? $edit_customer['email'] : ''; ?>">
                    </div>

                    <div class="form-group">
                        <label>Contact Number:</label>
                        <input type="text" name="contact" 
                               value="<?php echo $edit_customer ? $edit_customer['contact'] : ''; ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label>Address:</label>
                    <textarea name="address" rows="3"><?php echo $edit_customer ? $edit_customer['address'] : ''; ?></textarea>
                </div>

                <div>
                    <?php if ($edit_customer): ?>
                        <button type="submit" name="update_customer" value="1" class="btn">Update Customer</button>
                        <a href="customers.php" class="btn" style="background: #6c757d;">Cancel</a>
                    <?php else: ?>
                        <button type="submit" name="add_customer" value="1" class="btn">Add Customer</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Customers Table -->
        <div class="form-container">
            <h3>All Customers</h3>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Actions</th>
                </tr>
                <?php
                $customers = $conn->query("SELECT * FROM customers ORDER BY customer_id DESC");

                if ($customers && $customers->num_rows > 0) {
                    while ($customer = $customers->fetch_assoc()) {
                        $short_address = strlen($customer['address']) > 50 ? 
                            substr($customer['address'], 0, 50) . '...' : $customer['address'];
                        
                        echo "<tr>
                            <td>{$customer['customer_id']}</td>
                            <td>{$customer['name']}</td>
                            <td>{$customer['email']}</td>
                            <td>{$customer['contact']}</td>
                            <td title='{$customer['address']}'>{$short_address}</td>
                            <td>
                                <a href='customers.php?edit={$customer['customer_id']}' class='btn' style='background: #ffc107; color: black;'>Edit</a>
                                <a href='customers.php?delete={$customer['customer_id']}' 
                                   class='btn btn-danger' 
                                   onclick='return confirm(\"Are you sure you want to delete this customer?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' style='text-align: center;'>No customers found</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>